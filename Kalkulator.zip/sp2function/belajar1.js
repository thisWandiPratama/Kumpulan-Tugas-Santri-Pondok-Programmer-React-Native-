function data(nama) {
    document.write(nama)
}
data('Ahmad ElFath')