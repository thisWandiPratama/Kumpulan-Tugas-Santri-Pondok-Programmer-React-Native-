function data(nama='Pondok IT') {
    document.write(nama)
}
data()
//Diatas merupakan contoh Function Default
