function data(nama, alamat) {
    document.write('nama saya :' + nama +  '<br>asal :' + alamat)
}
data('Ahmad ElFath', 'Blitar')