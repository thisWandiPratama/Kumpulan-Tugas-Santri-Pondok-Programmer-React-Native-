function data(nama, ...other) {
    document.write(nama + ',' + other.join(',') )
}
data("Ahmad ElFath",12 , 23 , 24)