// var panjang = parseInt (prompt('Enter a Height'))
// var lebar   = parseInt (prompt('Enter a Large'))
// var luas    = panjang * lebar
// document.write(luas)


// var konfirmasi = confirm('Are you Sure???')
// document.write(konfirmasi)

// function luasPersegi(p,l) {
//     var luas = p * l
//     document.write(luas)
// }
// var n1 = parseInt (prompt('Masukan nilai Panjang'))
// var n2 = parseInt (prompt('Masukan nilai Lebar'))
// luasPersegi (n1 , n2)

// // function logic(nilai){
// // for (y = 1; y <= nilai; y++) {
// //   for (x = 1; x <= nilai; x++) {
// //     if (y == 1) {
// //       document.write (' x ');
// //     } 
// //     else if (x == 1) {
// //       document.write (' x ');
// //     }
// //     else if (y == nilai){
// //         document.write(' x ')
// //     }
// //     else if (x == nilai){
// //         document.write(' x ')
// //     }
// //     else if (y== nilai/2+0.5 && x== nilai/2+0.5){
// //         document.write(' x ')
// //     }
// //      else {
// //       document.write (' o ');
// //     }
// //   }

// //   document.write ('<br>');
// // }

// // }
// // var value = parseInt(prompt('Masukan Nilai'))
// // logic (value)

// function programMakanan() {
//     var masukan = prompt ('Enter Foods Name etc : Ayam , Sate , Soto');
// switch (masukan) {
//   case 'ayam':
//     alert ('you choose ayam');
//     break;
//   case 'sate':
//     alert ('you choose sate ');
//     break;
//   case 'soto':
//     alert ('you choose soto');
//     break;
//   default:
//     alert ('404 Not Found');
//     break;
// }
// var konfirmasi = confirm('you want to try again??')
// if (konfirmasi==true){
//     programMakanan()
// }
// else if (konfirmasi==false){
//     return false
// }

// }
// programMakanan()