for (n=0; n<9; n++) {
    var a = n*2
    document.write(a)
}