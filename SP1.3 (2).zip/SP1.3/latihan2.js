for (n = 1; n <= 9; n++) {
    var a = n * 2 -1
    document.write(a)
}