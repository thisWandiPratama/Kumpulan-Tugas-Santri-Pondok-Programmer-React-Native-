for (y=1; y<=5; y++){
    for (x=1; x<=5; x++){
        if (x<=y){
            document.write(x)
        }else {
            document.write()
        }
    }
document.write('<br>')
}