for (y=1; y<=9; y++) {
    for (x=1; x<=9; x++) {
        if (y%2==0){
            document.write('+')
        }else{
            document.write('-')
        }
    }
    document.write('<br>')
}