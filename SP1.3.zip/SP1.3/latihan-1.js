var n = 9;
for (let a = 0; a <= n; a++) {
    
    var nilai = a*2;
    if(nilai != "18"){
        document.write(nilai+" ")
    }
    
}