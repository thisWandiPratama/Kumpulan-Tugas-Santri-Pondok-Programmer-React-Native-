var n = 9;
var a = 1;
while(a < n*2){
    document.write(a+" ")
    
    a+=2
}