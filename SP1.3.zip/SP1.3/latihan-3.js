for (let index = 1; index <=5 ; index++) {
    
    for (let indexX = 1; indexX <= 5; indexX++) {
        
        if (indexX <= index) {
            
            document.write(indexX+" ")

        }

    }

    document.write('<br>')

}