for (let index = 1; index < 10; index++) {
    if((index % 2) != 0){

        for (let indexX = 1; indexX < 10; indexX++) {
        
            document.write(" - ")
    
        }

    }else{

        for (let indexX = 1; indexX < 10; indexX++) {
        
            document.write(" + ")
    
        }

    }

    document.write("<br>")
    
}