for (let index = 1; index <=9 ; index++) {

    for (let indexX = 9; indexX >= 1; indexX--) {
        
        if (indexX == index) {
            
            document.write(" + ")

        }else if(indexX == 10 - index){

            document.write(" + ")

        }else{

            document.write(" - ")

        }

    }
    
    document.write('<br>')

}