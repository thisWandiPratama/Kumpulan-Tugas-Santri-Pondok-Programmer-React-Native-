for (let index = 1; index <=10 ; index++) {
    
    for (let indexX = 1; indexX <= 10; indexX++) {
        
        if (indexX == index) {
            
            document.write(" + ")

        }else if(indexX <= index){

            document.write(" + ")

        }else{

            document.write(" - ")

        }

    }

    document.write('<br>')

}