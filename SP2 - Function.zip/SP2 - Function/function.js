// No. 1

// function divisi(nama) {
//     document.write(nama)
// }

// divisi('React Native')


// No. 2

// function divisi(nama='React Native') {
//     document.write(nama)
// }

// divisi()


// No. 3

// function jurusan($1, $2, $3) {
//     document.write($1+' - '+$2+' - '+$3)
// }

// jurusan('Back End', 'Front End', 'Mobile')



// No. 4

// function jurusan($1, $2, ...$3) {
//     document.write($1+' - '+$2+' - '+$3.join(' & '))
// }

// jurusan('Back End', 'Front End', 'Mobile: Java', 'Mobile: Javascript')