// Enkapsulasi

class persegiPanjang{
    constructor(){
        this.panjang = 20
        this.lebar   = 10
    }
    hitung(){
        return this.panjang * this.lebar
    }
}
var Pp = new persegiPanjang()
console.log(Pp.hitung())