// Instansiasi

class persegiPanjang{
    constructor(panjang, lebar){
        this.panjang = panjang
        this.lebar   = lebar
    }
    hitung(){
        return this.panjang * this.lebar
    }
}
let Pp = new persegiPanjang(10, 90)
console.log(Pp.hitung())