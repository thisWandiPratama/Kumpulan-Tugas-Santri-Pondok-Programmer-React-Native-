// Inheritance

class persegiPanjang{
    constructor(panjang, lebar){
        this.panjang = panjang
        this.lebar   = lebar
    }
    hitung(){
        return this.panjang * this.lebar
    }
}

class Hitung extends persegiPanjang{
    constructor(panjang, lebar){
        super (panjang, lebar)
    }
}

const Pp = new Hitung(50, 3)
console.log(Pp.hitung())