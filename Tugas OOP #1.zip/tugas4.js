// Polymorpism

function person(gender) {
    this.gender = gender
    this.sayHi  = () => {
        if (gender === 0) {
            console.log('Hi Madam')
            
        }else if(gender === 1){
            console.log('Hi Sir')

        }else{
            console.log('Hi ...')
        }
    }
}

var people = new person(0)
people.sayHi()