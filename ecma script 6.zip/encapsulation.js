class persegipanjang {
    constructor() {
        this.panjang = 20
        this.lebar = 12
    }
    luaspersegipanjang() {
        return this.panjang * this.lebar
    }
}
const bunga = new persegipanjang()
console.log(bunga.luaspersegipanjang())


// class PersegiPanjang {
//     constructor() {
//         this.panjang = 20
//         this.lebar = 11
//     }
//     hitungLuasPersegiPanjang() {
//         return this.panjang * this.lebar
//     }
// }
// var bebas = new PersegiPanjang()
// console.log(bebas.hitungLuasPersegiPanjang())