class persegipanjang {
    constructor(panjang, lebar) {
        this.panjang = panjang
        this.lebar = lebar
    }
    luaspersegipanjang() {
        return this.panjang * this.lebar
    }
}

class hitung extends persegipanjang {

}
const hasil = new persegipanjang(10, 23)

console.log(hasil.luaspersegipanjang())