class persigipanjang {
    constructor(panjang, lebar) {
        this.panjang = panjang
        this.lebar = lebar

    }
    hitungluaspersegipanajang() {
        return this.panjang * this.lebar
    }
}
let hasilnya = new persigipanjang(20, 12)
console.log(hasilnya)