//banyak argumen
function dataDiri(nama, umur) {
    document.write('nama ' + nama + ' umur ' + umur)
}
dataDiri('rizqan', 17)

document.write('<br>')