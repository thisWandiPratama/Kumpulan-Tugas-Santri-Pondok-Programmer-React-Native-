//nilai default
function dataDiri(nama = 'Rizqan') {
    document.write(nama)
}
dataDiri()

document.write('<br>')

function dataDiri(nama = 'Rizqan') {
    document.write(nama)
}
dataDiri('Ramadhani')

document.write('<br>')
