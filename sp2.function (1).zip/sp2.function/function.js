//function biasa
function dataDiri(nama){
    document.write(nama)
}
dataDiri('Rizqan')

document.write('<br>')

//nilai default
function dataDiri(nama='Rizqan'){
    document.write(nama)
}
dataDiri()
document.write('<br>')
function dataDiri(nama = 'Rizqan') {
    document.write(nama)
}
dataDiri('Ramadhani')

document.write('<br>')
