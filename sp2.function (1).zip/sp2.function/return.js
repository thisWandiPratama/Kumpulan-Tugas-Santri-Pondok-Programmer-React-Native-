//ini return
function dataDiri(nama, ...other) {
    return document.write(nama + ' ' + other.join('.'));
    document.write('test doang')
}
dataDiri('rizqan', 17, 18)