//spread
function dataDiri(nama, ...other) {
    document.write(nama + ' ' +other.join('.'));
}
dataDiri('rizqan', 17, 18)

document.write('<br>')