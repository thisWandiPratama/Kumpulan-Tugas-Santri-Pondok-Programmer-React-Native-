function data(nama) {
    document.write(nama)
}

data("arifin")