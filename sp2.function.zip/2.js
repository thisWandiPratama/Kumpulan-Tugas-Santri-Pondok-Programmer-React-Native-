function data(nama = "pondok it") {
    document.write(nama)
}

data()