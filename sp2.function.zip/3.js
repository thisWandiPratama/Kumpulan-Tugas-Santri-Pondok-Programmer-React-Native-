function data(nama, sekolah) {
    document.write("nama saya" + " " + nama + " " + "asal" + " " + sekolah)
}

data("arifin", "kediri")