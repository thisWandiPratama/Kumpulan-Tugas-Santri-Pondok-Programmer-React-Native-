function data(nama, ...other) {
    document.write(nama + "," + other.join(","))
}

data("arifin", 12, 23, 43)