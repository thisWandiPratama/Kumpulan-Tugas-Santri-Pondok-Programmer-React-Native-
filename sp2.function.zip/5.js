function data(nama) {
    return document.write(nama)
    document.write("test")
}

data("arifin")