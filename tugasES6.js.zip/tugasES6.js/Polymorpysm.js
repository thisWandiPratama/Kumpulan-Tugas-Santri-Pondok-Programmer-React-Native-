function person(gender){
    this.gender = gender
    this.saya = () =>{
        if(gender === 1){
            console.log(true)
        }else if (gender === 2){
            console.log(true)
        }else{
        console.log(false)
        }
    }
}
var a = new person(1)
let b = new person(1)
const c = new person(1)
a.saya()
b.saya()
c.saya()