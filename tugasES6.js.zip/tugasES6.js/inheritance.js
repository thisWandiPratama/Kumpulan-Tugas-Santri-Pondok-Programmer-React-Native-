class luas {
    constructor(panjang, lebar) {
        this.panjang = panjang
        this.lebar = lebar
    }
    hitung() {
        return this.panjang * this.lebar
    }
}

class persegipanjang extends luas{
  
}
const jumlah = new luas(4, 10)
console.log(jumlah.hitung())