class luas{
    constructor(){
        this.panjang = 10
        this.lebar = 5
    }
    hitung(){
        return this.panjang*this.lebar
    }
}
var jumlah = new luas()
console.log(jumlah.hitung())