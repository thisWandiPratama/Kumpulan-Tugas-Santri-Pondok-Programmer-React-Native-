class luas {
    constructor(panjang, lebar) {
        this.panjang = panjang
        this.lebar = lebar
    }
    hitung() {
        return this.panjang * this.lebar
    }
}
let jumlah = new luas(9, 10)
console.log(jumlah.hitung())